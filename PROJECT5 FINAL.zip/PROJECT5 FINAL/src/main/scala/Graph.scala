import org.apache.spark.SparkConf //importing apache spark packages
import org.apache.spark.SparkContext //importing apache spark context
import scala.math.min //importing scala math min
@SerialVersionUID(123L)
case class Object1(aNode:Long, aGrp:Long, bGrp:Long) extends Serializable{} //class object1 extends Serializable
  object Graph{
    def main(args: Array[String]){ //main program
      val conf = new SparkConf().setAppName("Project_5") //sparkconf set app name
      val sc = new SparkContext(conf) //using scanner


      var graph = sc.textFile(args(0)).map( line => { val a = line.split(",")
                                                      (a(0).toLong,a(0).toLong,a.drop(1).toList.map(_.toLong)) }) //split the function

      var graph_1 = graph.map(g => (g._1,g)) //map the graph
      graph_1.foreach(println) //printing the graph

      for(i <- 1 to 5){ //using for loop
         graph = graph.flatMap(
         map => map match{ case (p, q, pq) => (p, q) :: pq.map(r => (r, q) ) } )
        .reduceByKey((u, v) => (if (u >= v) v else u)) //reduce by key
        .join(graph_1).map(g => (g._2._2._2, g._2._1, g._2._2._3)) //using join
    }

    val groupCount = graph.map(g => (g._2, 1)) //graph.map 
    .reduceByKey((c, d) => (c + d)) //reduce by Key
    .sortBy(_._1) //sorting 
    .collect() //collects
    .foreach(println) //printing 
    }
}
