import java.io.DataInput;//Importing java packages 
import java.io.DataOutput;//importing java dataoutput packages 
import java.io.IOException; //importing java exception package
import java.util.Scanner;//importing java scanner

import org.apache.hadoop.conf.Configuration;//importing hadoop packages 
import org.apache.hadoop.conf.Configured;//importing hadoop conf configured packages
import org.apache.hadoop.fs.Path;//importing apache packages
import org.apache.hadoop.io.*;//importing apache hadoop io
import org.apache.hadoop.mapreduce.*;//importing apache hadoop mapreduce 
import org.apache.hadoop.mapreduce.lib.input.*; //importing hadoop mapreduce lib input
import org.apache.hadoop.mapreduce.lib.output.*;//importing hadoop mapreduce lib output
import org.apache.hadoop.util.Tool;//importing org apache 
import org.apache.hadoop.util.ToolRunner;//importing tool runner 
//Vertex class implements writable
class Vertex implements Writable{
	int tag;
	long group;
	long vid;
	String adjacent = "";

	Vertex(){}

	Vertex(int t, long g)
	{
		tag = t;
		group = g;
	}

	Vertex(int t, long g, long v, String a)
	{
		tag = t;
		group = g;
		vid = v;
		adjacent = a;
	}

	public void readFields(DataInput in) throws IOException {
		tag = in.readInt();
		group = in.readLong();
		vid = in.readLong();
		adjacent = in.readLine();

	}

	public void write(DataOutput out) throws IOException {
		out.writeInt(tag);
		out.writeLong(group);
		out.writeLong(vid);
		out.writeBytes(adjacent);
	}

}

public class Graph extends Configured implements Tool {

	////------------------------FIRST MAPPER IS EXECUTED AS FOLLOWS--------------------------------------------------

	public static class My_Mapper1 extends Mapper<LongWritable,Text,LongWritable,Vertex>{
		@Override
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
			Scanner t = new Scanner(value.toString()).useDelimiter(",");//scanner creation
			int vid = t.nextInt();
			String Adj =Integer.toString(t.nextInt());
			while(t.hasNext())
			{
				Adj = Adj + "," + t.nextInt();
			}


			Vertex v = new Vertex(0,vid,vid,Adj);//vertex creation
			context.write(new LongWritable(v.vid), v);//emits vid
		}
	}
////---------------------------FIRST REDUCER IS EXECUTED AS FOLLOWS-----------------------------------------------------
	public static class My_Reducer1 extends Reducer<LongWritable,Vertex,Text,Text>
	{
		@Override
		public void reduce(LongWritable key, Iterable<Vertex> value,Context context) throws IOException,InterruptedException{
			for(Vertex v: value)
			{
				Text values = new Text();
				Text keys = new Text();
				keys.set(key.toString());
				values.set("," + v.tag + "," + v.group + "," + v.vid + "," + v.adjacent);
				context.write(keys, values);//emits keys and values
			}
		}
	}
	//----------------MAPPER2 IS IMPLEMENTED IN THE BELOW PROCEDURE-----------------------------------------------------------
	public static class My_Mapper2 extends Mapper<LongWritable,Text,LongWritable,Vertex>{
		@Override
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
			Scanner t = new Scanner(value.toString().replaceAll("\\s+", "")).useDelimiter(",");
			int keyz = t.nextInt();
			int tag = t.nextInt();
			int group = t.nextInt();
			int vid = t.nextInt();
			String adjacent = "";
			while(t.hasNext())
			{
				if(adjacent.isEmpty()) //if adjacent is empty
				{
					adjacent = Integer.toString(t.nextInt());
				}
				else
				{
					adjacent = adjacent + "," + Integer.toString(t.nextInt());
				}
			}
			Vertex v = new Vertex(tag,group,vid,adjacent);//vertex
			context.write(new LongWritable(v.vid), v);//emits v.vid and v
			
			if(!adjacent.isEmpty()) //if adjacent is not empty
			{
				Scanner t1 = new Scanner(adjacent).useDelimiter(","); //scanner t1 is created
				while(t1.hasNext())
				{
					Vertex v1 = new Vertex(1,v.group);
					context.write(new LongWritable(t1.nextInt()), v1); //emits t1 and v1
				}
			}
		}
	}
	//  SECOND REDUCER: -------------------->IS SHOWN
	public static class My_Reducer2 extends Reducer<LongWritable,Vertex,Text,Text>
	{
		@Override
		public void reduce(LongWritable key, Iterable<Vertex> value,Context context) throws IOException,InterruptedException{
			long max = Long.MAX_VALUE;
			Text c = new Text();
			Text d = new Text();
			String adjacent = "";
			for(Vertex v:value)
			{
				if(v.tag == 0)
				{
					adjacent = v.adjacent;
				}
				max = Math.min(max, v.group);
			}
			c.set(Long.toString(max));
			Vertex v2 = new Vertex(0,max,key.get(),adjacent);
			d.set("," + 0 + "," + v2.group + "," + v2.vid + "," + v2.adjacent);
			context.write(c,d); //emits c and d
		}
	}

	//-------------------------Mapper 3 is as follows-------------------------------
	public static class My_Mapper3 extends Mapper<LongWritable,Text,LongWritable,IntWritable>{
		@Override
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
			Scanner t = new Scanner(value.toString().replaceAll("\\s+", "")).useDelimiter(",");
			int group = t.nextInt();
			context.write(new LongWritable(group), new IntWritable(1)); //emits group 
		}
	}
    ///REDUCER3 IS SHOWN HERE IN THE BELOW PROCEDURE----------------------------------------------------
	public static class My_Reducer3 extends Reducer<LongWritable,IntWritable,Text,Text>
	{
		@Override
		public void reduce(LongWritable key, Iterable<IntWritable> value,Context context) throws IOException,InterruptedException{
			int m = 0;
			for(IntWritable v:value)
			{
				m = m + v.get();
			}
			Text c = new Text();
			Text d = new Text();
			c.set(Long.toString(key.get()));
			d.set(Integer.toString(m)); //set to integer
			context.write(c,d); //emits c and d 
		}
	}

	//----------------MAIN METHOD IMPLEMENTATION IS SHOWN HERE IN THE BELOW PROCESS---------------------------------------
    public static void main ( String[] args ) throws Exception {
    	int foo = ToolRunner.run(new Configuration(), new Graph(),args); //tool runner
    	System.exit(foo);
    }
    public int run(String[] args)throws Exception
    {
    	Configuration conf = new Configuration(); //config is created
    	Job kxg3373_job1 = Job.getInstance(conf, "My job"); //Job1 is created
    	kxg3373_job1.setJarByClass(Graph.class); //Graph.class is set
    	kxg3373_job1.setMapperClass(My_Mapper1.class); //Mapper1
    	kxg3373_job1.setReducerClass(My_Reducer1.class); //Reducer1
    	kxg3373_job1.setMapOutputKeyClass(LongWritable.class);
    	kxg3373_job1.setMapOutputValueClass(Vertex.class); //Class vertex
    	kxg3373_job1.setOutputKeyClass(Text.class);
    	kxg3373_job1.setOutputValueClass(Text.class);
    	FileInputFormat.addInputPath(kxg3373_job1, new Path(args[0]));
    	FileOutputFormat.setOutputPath(kxg3373_job1, new Path(args[1] + "/f0"));
    	kxg3373_job1.waitForCompletion(true); //waits for completion to true


		int iterations;
		for(iterations = 0; iterations < 5; iterations++)
		{
			Configuration conf2 = new Configuration(); //config is created
	    	Job kxg3373_job2 = Job.getInstance(conf2, "My job"); //Job2 is created
	    	kxg3373_job2.setJarByClass(Graph.class); //Graph.class is set
	    	kxg3373_job2.setMapperClass(My_Mapper2 .class); //Mapper2
	    	kxg3373_job2.setReducerClass(My_Reducer2.class); //Reducer2
	    	kxg3373_job2.setMapOutputKeyClass(LongWritable.class);
	    	kxg3373_job2.setMapOutputValueClass(Vertex.class);
	    	kxg3373_job2.setOutputKeyClass(Text.class);
	    	kxg3373_job2.setOutputValueClass(Text.class);
	    	FileInputFormat.addInputPath(kxg3373_job2, new Path(args[1] + "/f" + iterations));
	    	FileOutputFormat.setOutputPath(kxg3373_job2, new Path(args[1] + "/f" + (iterations + 1)));
	    	kxg3373_job2.waitForCompletion(true); //waits for completion to true
		}


		Configuration conf3 = new Configuration(); //config is created
    	Job kxg3373_job3 = Job.getInstance(conf3, "My job"); //Job3 is created 
    	kxg3373_job3.setJarByClass(Graph.class); //Graph.class is set
    	kxg3373_job3.setMapperClass(My_Mapper3.class); //Mapper3
    	kxg3373_job3.setReducerClass(My_Reducer3.class); //Reducer3
    	kxg3373_job3.setMapOutputKeyClass(LongWritable.class);
    	kxg3373_job3.setMapOutputValueClass(IntWritable.class);
    	kxg3373_job3.setOutputKeyClass(Text.class);
    	kxg3373_job3.setOutputValueClass(Text.class);
    	FileInputFormat.addInputPath(kxg3373_job3, new Path(args[1] + "/f5"));
    	FileOutputFormat.setOutputPath(kxg3373_job3, new Path(args[2]));
    	kxg3373_job3.waitForCompletion(true); //waits for completion to true
		return 0;
    }
}