import java.io.*;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;
//import org.w3c.dom.Text;
import org.apache.hadoop.io.Text;


public class Netflix {
    public static class MyMapper1 extends Mapper<Object,Text,IntWritable,DoubleWritable> {
        @Override
        public void map(Object key, Text value, Context context )
        throws IOException, InterruptedException {
            //System.out.println("sssss   :"+value.toString());
            Scanner s = new Scanner(value.toString()).useDelimiter(",");
            //System.out.println(" TEXT obj value  "+ value.toString());
            //Scanner s = new Scanner(value.nextLine().toString().split(","));
            String[] ele = s.nextLine().toString().split(",");
            if(ele.length != 1){

               int user = Integer.parseInt(ele[0]);
                double rating = Double.parseDouble(ele[1]);
                //int user = NumberUtils.toInt(ele[0]);
                //double rating = NumberUtils.toDouble(ele[1]);
                context.write(new IntWritable(user), new DoubleWritable(rating));
            }
                //System.out.println("two ele  "+ele[0]+"    "+ele[1]);
            //}
            //else
            //    System.out.println("one  "+ele[0]);
            //int user = s.nextInt();
            //double rating = s.nextDouble();
            //System.out.println("user:" +user+ " value  :"+value);
            //s.close();
        }
    }
    public static class MyReducer1 extends Reducer<IntWritable,DoubleWritable,IntWritable,IntWritable> {
        @Override
        public void reduce (IntWritable user, Iterable<DoubleWritable> ratings,  Context context )
        throws IOException, InterruptedException {
            int count = 0;
            double sum = 0;
            for (DoubleWritable n: ratings) {
                count++;
                sum = sum + n.get();
            }
            context.write(user,new IntWritable((int)(sum/count*10)));
        }
    }
    public static class MyMapper2 extends Mapper<Object,Text,DoubleWritable, IntWritable>{
        @Override
        public void map (Object key, Text value, Context context )
        throws IOException, InterruptedException {
                    Scanner s = new Scanner(value.toString()).useDelimiter("\t");
                    int user = s.nextInt();
                    double rating = s.nextDouble();
                    context.write(new DoubleWritable(rating),new IntWritable(1));
                    s.close();
        }
    }
    public static class MyReducer2 extends Reducer<DoubleWritable,IntWritable,DoubleWritable,IntWritable> {
        @Override
        public void reduce (DoubleWritable rating,Iterable<IntWritable> values,Context context )
        throws IOException, InterruptedException {
                int sum = 0;
                //long count = 0;
                for (IntWritable v: values) {
                    sum += v.get();
                    //count++;
                };
//                context.write(new DoubleWritable(rating.get()/10.0), new IntWritable(sum/count));
                context.write(new DoubleWritable(rating.get()/10), new IntWritable(sum));
        }
    }

    public static void main ( String[] args ) throws Exception {
        Job netflix_job1 = Job.getInstance();
        netflix_job1.setJobName("NETFLIX_JOB1");
        netflix_job1.setJarByClass(Netflix.class);
        netflix_job1.setOutputKeyClass(IntWritable.class);
        netflix_job1.setOutputValueClass(DoubleWritable.class);
        netflix_job1.setMapOutputKeyClass(IntWritable.class);
        netflix_job1.setMapOutputValueClass(DoubleWritable.class);
        netflix_job1.setMapperClass(MyMapper1.class);
        netflix_job1.setReducerClass(MyReducer1.class);
        netflix_job1.setInputFormatClass(TextInputFormat.class);
        netflix_job1.setOutputFormatClass(TextOutputFormat.class);
        FileInputFormat.setInputPaths(netflix_job1,new Path(args[0]));
        FileOutputFormat.setOutputPath(netflix_job1,new Path(args[1]));
        netflix_job1.waitForCompletion(true);

        Job netflix_job2 = Job.getInstance();
        netflix_job2.setJobName("NETFLIX_JOB2");
        netflix_job2.setJarByClass(Netflix.class);
        netflix_job2.setOutputKeyClass(DoubleWritable.class);
        netflix_job2.setOutputValueClass(DoubleWritable.class);
        netflix_job2.setMapOutputKeyClass(DoubleWritable.class);
        netflix_job2.setMapOutputValueClass(IntWritable.class);
        netflix_job2.setMapperClass(MyMapper2.class);
        netflix_job2.setReducerClass(MyReducer2.class);
        netflix_job2.setInputFormatClass(TextInputFormat.class);
        netflix_job2.setOutputFormatClass(TextOutputFormat.class);
        FileInputFormat.setInputPaths(netflix_job2,new Path(args[1]));
        FileOutputFormat.setOutputPath(netflix_job2,new Path(args[2]));
        netflix_job2.waitForCompletion(true);
    }
}

