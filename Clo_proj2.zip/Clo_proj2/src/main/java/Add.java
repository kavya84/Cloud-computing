import java.io.*;  // importing java.io package
import java.util.*; //importing util package for java
import org.apache.hadoop.conf.*; //importing org.apache.hadoop.conf packages
import org.apache.hadoop.util.*; //importing org.apache.hadoop.util.* packages
import org.apache.hadoop.fs.Path;//importing apache fspath packages 
import org.apache.hadoop.io.*; //importing apache hadoop.io packages 
import org.apache.hadoop.mapreduce.*; //importing apache hadoop.mapreduce packages 
import org.apache.hadoop.mapreduce.lib.input.*; //importing apache hadoop.mapreduce.lib.input.* packages
import org.apache.hadoop.mapreduce.lib.output.*; //importing apache hadoop.mapreduce.lib.output.* packages 
//Triple class implementation
class Triple implements Writable {
    public int i;  //declaring i as int
    public int j;  //declaring j as int
    public double value;  //declaring value as double

    Triple () {}

    Triple ( int i, int j, double v ) { this.i = i; this.j = j; value = v; }

    public void write ( DataOutput out ) throws IOException {
        out.writeInt(this.i);  //writing i
        out.writeInt(this.j);  //writing j
        out.writeDouble(value); //writing value
    }

    public void readFields ( DataInput in ) throws IOException {
        this.i=in.readInt();  //reading 'i'
        this.j=in.readInt();  //reading 'j'
        value=in.readDouble();//reading 'value'

    }

    @Override
    public String toString () {
        return ""+i+"\t"+j+"\t"+value;  //returns i,j,value
    }
}
//Block class implementation 
class Block implements Writable {
    final static int rows = 100;     //declaring the rows in the block using final static
    final static int columns = 100;  //declaring the columns in the block using final static
    public double[][] data;          //declaring data in the block

    Block () {
        data = new double[rows][columns];   //data in terms of rows and columns 
    }

    public void write ( DataOutput out ) throws IOException {
        //out.writeInt(rows);
        //out.writeInt(columns);
        //out.writeDouble(data[100][100]);
        for ( int i = 0; i < rows; i++ ) {
            for ( int j = 0; j < columns; j++ )        //using 'for loop' for rows and columns
                out.writeDouble(data[i][j]) ;          //using out.writeDouble to obtain the data 
        }
    }

    public void readFields ( DataInput in ) throws IOException {
      //  this.data=new double[100][100];
      for ( int i = 0; i < rows; i++ ) {                    //using for loop to initialize and increment the rows and columns
        for ( int j = 0; j < columns; j++ )
            data[i][j]=in.readDouble() ;                   //using in.readDouble to read the data 
    }
}

    @Override
    public String toString () {
        String s = "\n";
        for ( int i = 0; i < rows; i++ ) {                 //using for loop to initialize and increment the rows and columns
            for ( int j = 0; j < columns; j++ )
                s += String.format("\t%.3f",data[i][j]);
            s += "\n";
        }
        return s;                                         //returns the string 
    }
}
//Pair class implementation
class Pair implements WritableComparable<Pair> {
    public int i;                                        //declaring 'i'
    public int j;                                        //declaring 'j'

    Pair () {}

    Pair ( int i, int j ) { this.i = i; this.j = j; }       

    public void write ( DataOutput out ) throws IOException {
        out.writeInt(this.i);                            //writing i using out.writeInt(this.i)
        out.writeInt(this.j);                            //writing j using out.writeInt(this.j)
    }

    public void readFields ( DataInput in ) throws IOException {
        this.i=in.readInt();                            //reading i using in.readInt()
        this.j=in.readInt();                            //reading j using in.readInt()
    }

    @Override
    public int compareTo ( Pair o )  // compareTo is used in reducers for sorting
    {
        if(i==o.i)          //comparision using pair
        {
            return j-o.j;  //returns the difference of indices j and o.j
        }
        return i-o.i;   // returns the difference of indices i and o.i
    }

    @Override
    public String toString () {
        return ""+i+"\t"+j;    //returns " ",i,"\t",j 
    }
}

public class Add extends Configured implements Tool {
    final static int rows = Block.rows; //Declaring the rows in block
    final static int columns = Block.columns; //Declaring the columns in block
//MyMapper 1 for Matrix M
    public static class MyMapper1 extends Mapper<Object, Text, Pair, Triple>{
        @Override
        public void map(Object key, Text value, Context context)
        throws IOException, InterruptedException{
            Scanner w = new Scanner(value.toString()).useDelimiter(","); //using scanner and delimiter 
            int i = w.nextInt(); //reading i value
            int j = w.nextInt(); //reading j value
            double v = w.nextDouble(); // reading v value
            context.write(new Pair(i/rows,j/columns),(new Triple(i%rows,j%columns,v))); //emits pair and triple
       }
    }

//MyReducer1

public static class MyReducer1 extends Reducer<Pair,Triple,Pair,Block> {
       @Override
        public void reduce ( Pair key, Iterable<Triple> values, Context context )
        throws IOException, InterruptedException {
            Block b= new Block(); //Initializing the empty block 'b'
               for(Triple value:values){ //iterating i,j and v values in triple using for loop
                b.data[value.i][value.j]=value.value; //assigning the value to the block matrix
               }
         context.write(key,b); //emits pair and block
        }
    }
    //MyMapper2
    public static class MyMapper2 extends Mapper<Pair,Block, Pair, Block>{
        public void map(Pair key, Block block, Context context)
        throws IOException, InterruptedException{

            context.write(key, block); //emits pair and block
        }
    }
//Myreducer2
public static class MyReducer2 extends Reducer<Pair,Block,Pair,Block> {
        @Override
        public void reduce ( Pair key, Iterable<Block> values, Context context )
                           throws IOException, InterruptedException {
          Block s= new Block(); // initializing the empty block 's'
            for (Block b: values) { //for b in blocks
                for (int i=0; i<rows; i++ ){  // initializing and incrementing rows
                    for (int j=0; j < columns; j++){ // initializing and incrementing columns
                        s.data[i][j] += b.data[i][j];//Java matrix addition for blocks
                    }
                }
            };
            context.write(key,s);//emits pair and 's'
        }
    }
    @Override
    public int run ( String[] args ) throws Exception {
        /* ... */
        return 0; //returns 0
    }
//Main program 
    public static void main ( String[] args ) throws Exception {

        ToolRunner.run(new Configuration(),new Add(),args);     //Tool runner 

        Job kxg3373_JOB1 = Job.getInstance();                   //Creating 1st job kxg3373_JOB1
        kxg3373_JOB1.setJobName("KXG3373_JOB1");                //Set job name for 1st job
        kxg3373_JOB1.setJarByClass(Add.class);                  //Set Jar by class as 'Add class' 
        kxg3373_JOB1.setOutputKeyClass(Pair.class);             //Set Output key class to 'pair class'
        kxg3373_JOB1.setOutputValueClass(Block.class);          //Set Output value class to 'Block class'
        kxg3373_JOB1.setMapOutputKeyClass(Pair.class);          //Set Map Output key class to 'Pair class'
        kxg3373_JOB1.setMapOutputValueClass(Triple.class);      //Set MapOutput value class to 'Triple class'
        kxg3373_JOB1.setMapperClass(MyMapper1.class);           //Set Mymapper1 class to Mapper class
        kxg3373_JOB1.setReducerClass(MyReducer1.class);         //Set Myreducer1 class to reducer class 
        kxg3373_JOB1.setInputFormatClass(TextInputFormat.class);//Set Text Input format to text input format class
        kxg3373_JOB1.setOutputFormatClass(SequenceFileOutputFormat.class); //Set Output format class to Sequence file output format class
        FileInputFormat.addInputPath(kxg3373_JOB1,new Path(args[0])); //Add input path 
        SequenceFileOutputFormat.setOutputPath(kxg3373_JOB1,new Path(args[2])); // Set Output path using Sequence File output format class
        kxg3373_JOB1.waitForCompletion(true);                   //Set Wait for completion to true


        Job kxg3373_JOB2 = Job.getInstance();                   //Creating 2nd job kxg3373_JOB2
        kxg3373_JOB2.setJobName("KXG3373_JOB2");                //Set job name for 2nd job
        kxg3373_JOB2.setJarByClass(Add.class);                  //Set Jar by class as 'Add class'  
        kxg3373_JOB2.setOutputKeyClass(Pair.class);             //Set Output key class to 'pair class'
        kxg3373_JOB2.setOutputValueClass(Block.class);          //Set Output value class to 'Block class'
        kxg3373_JOB2.setMapOutputKeyClass(Pair.class);          //Set Map Output key class to 'Pair class'
        kxg3373_JOB2.setMapOutputValueClass(Triple.class);      //Set Map output value class to 'Triple class'
        kxg3373_JOB2.setMapperClass(MyMapper1.class);           //Set Mymapper1 class to Mapper class
        kxg3373_JOB2.setReducerClass(MyReducer1.class);         //Set Myreducer1 class to reducer class 
        kxg3373_JOB2.setInputFormatClass(TextInputFormat.class);//Set Text Input format to text input format class
        kxg3373_JOB2.setOutputFormatClass(SequenceFileOutputFormat.class); //Set Output format class to Sequence file output format class
        FileInputFormat.addInputPath(kxg3373_JOB2,new Path(args[1])); //Add input path 
        SequenceFileOutputFormat.setOutputPath(kxg3373_JOB2,new Path(args[3]));//Set Output path using Sequence File output format class
        kxg3373_JOB2.waitForCompletion(true);                   //Set Wait for completion to true

        Job kxg3373_JOB3 = Job.getInstance();                   //Creating 3rd job kxg3373_JOB3
        kxg3373_JOB3.setJobName("KXG3373_JOB3");                //Set job name for 3rd job
        kxg3373_JOB3.setJarByClass(Add.class);                  //Set Jar by class as 'Add class'
        kxg3373_JOB3.setOutputKeyClass(Pair.class);             //Set Output key class to 'pair class'
        kxg3373_JOB3.setOutputValueClass(Block.class);          //Set Output value class to 'Block class'
        kxg3373_JOB3.setMapOutputKeyClass(Pair.class);          //Set Map Output key class to 'Pair class'
        kxg3373_JOB3.setMapOutputValueClass(Block.class);       //Set Map output value class to 'Block class'
        kxg3373_JOB3.setMapperClass(MyMapper2.class);           //Set Mymapper2 class to Mapper class
        kxg3373_JOB3.setReducerClass(MyReducer2.class);         //Set Myreducer2 class to reducer class
        kxg3373_JOB3.setInputFormatClass(SequenceFileInputFormat.class); //Set Inputformat class to Sequence File Input format class
        kxg3373_JOB3.setOutputFormatClass(TextOutputFormat.class);       //Set Output format class to Text Output format class
        MultipleInputs.addInputPath(kxg3373_JOB3,new Path(args[2]),SequenceFileInputFormat.class,MyMapper2.class); //Add input path using Multiple inputs
        MultipleInputs.addInputPath(kxg3373_JOB3,new Path(args[3]),SequenceFileInputFormat.class,MyMapper2.class); //Add input path using Multiple inputs
        FileOutputFormat.setOutputPath(kxg3373_JOB3,new Path(args[4]));//Set output path
        kxg3373_JOB3.waitForCompletion(true);                  //Set wait for completion to true 

        

    }
}





