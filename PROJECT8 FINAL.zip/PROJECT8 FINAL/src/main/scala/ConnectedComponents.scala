import org.apache.spark.SparkContext//importing the required packages for Spark
import org.apache.spark.SparkConf //importing spark conf
import org.apache.spark.graphx.{Graph => Graph, VertexId,Edge} //importing spark.graphx
import org.apache.spark.graphx.util.GraphGenerators //importing spark.graphx.util.Grpahgenerators
import org.apache.spark.rdd.RDD //importing rdd

object ConnectedComponents {
  def main ( args: Array[String] ) {
    val conf = new SparkConf().setAppName("GraphX")

    val sc = new SparkContext(conf)
// A graph G is a dataset of vertices, where each vertex is (id,adj),
    // where id is the vertex id and adj is the list of outgoing neighbors
    // graph edges have attribute values 0

    val graphEdges: RDD[Edge[Long]]=sc.textFile(args(0)).map(line => { val (vertex, adjacent) = line.split(",").splitAt(1)
      (vertex(0).toLong,adjacent.toList.map(_.toLong))}).flatMap(e => e._2.map(v => (e._1,v))).map(node => Edge(node._1,node._2,node._1))
    // find the vertex new group # from its current group # and the group # from the incoming neighbors
    // send the vertex group # to the outgoing neighbors
    val graph: Graph[Long, Long]=Graph.fromEdges(graphEdges, "defValue").mapVertices((vid, _) => vid)
    // a vertex (id,group) has initial group equal to id
    // derive connected components using pregel
    val pregel_function = graph.pregel(Long.MaxValue,5)(
    (id, oldvalue, newvalue) => math.min(oldvalue, newvalue),
    triplet => {
      if (triplet.attr < triplet.dstAttr)
      {
        Iterator((triplet.dstId,triplet.attr))
      }
      else if (triplet.srcAttr < triplet.attr)
      {
        Iterator((triplet.dstId,triplet.srcAttr))
      }
      else
      {
        Iterator.empty
      }
    },
    (k,l) => math.min(k,l)
    )
   // print the group sizes (sorted by group #)
    val result = pregel_function.vertices.map(g => (g._2,1)).reduceByKey(_ + _).sortByKey().map(x => x._1.toString() + " " + x._2.toString())
    result.collect().foreach(println)
    
  }
}

