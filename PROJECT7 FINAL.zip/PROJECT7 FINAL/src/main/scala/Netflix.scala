import org.apache.spark._
import org.apache.spark.sql._

object Netflix {
  case class Rates ( user: Int, rating: Double )
  def main ( args: Array[ String ]): Unit = {
    val conf = new SparkConf().setAppName("Netflix")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    import spark.implicits._

    val p1 = spark.sparkContext.textFile(args(0)).filter(_.contains(","))
    val p2 = p1.map(_.split(",")).map(netflix => (netflix(0).toInt,netflix(1).toDouble)).toDF()
    p2.createOrReplaceTempView("P1")
    p2.show()
   val avg_3 = p2.groupBy("user").avg("rating")
   avg_3.show()
    /* ... */

  }
}